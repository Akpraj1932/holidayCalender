
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title text-center" style="border: 0;">
                    Academic Calender
                </div>
                <div class="clearfix"></div>
                <!-- menu profile quick info -->
                <div class="profile clearfix text-center">                   
                    <div class="profile_info">
                        <h2>  Admin Panel</h2>
                    </div>
                </div>
                <!-- /menu profile quick info -->
                <!-- sidebar menu -->
                <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                    <div class="menu_section">

                        <ul class="nav side-menu">
                            <li><a href ="home.php"><em class="fas fa-home"></em> Home</a></li>
                            
                                <!-- <li><a href ="users.php"><em class="fas fa-users"></em> Users</a></li> -->
                                <!-- <li>
                                    <a><em class="fas fa-th"></em> Leaderboard<span class="fas fa-caret-down"></span></a>
                                    <ul class="nav child_menu">
                                        <li><a href="global-leaderboard.php">All</a></li>
                                        <li><a href="monthly-leaderboard.php">Monthly</a></li>
                                        <li><a href="daily-leaderboard.php">Daily</a></li>                                       
                                    </ul>
                                </li>                                    -->
                                
                                    <!-- <li><a href="languages.php"><em class="fas fa-language"></em> Languages</a></li> -->
                              
                            <!--                            <li>
                                                            <a><em class="fas fa-gift"></em> Categories<span class="fas fa-caret-down"></span></a>
                                                            <ul class="nav child_menu">
                                                                <li><a href="main-category.php">Main Category</a></li>
                                                                <li><a href="sub-category.php">Sub Category</a></li>
                                                                <li><a href="category-order.php">Category Order</a></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="questions.php"><em class="fas fa-trophy"></em> Questions</a></li>-->
                            <li>
                                <a><em class="fas fa-book"></em> Academic Calender<span class="fas fa-caret-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="add_academic.php">Add</a></li>
                                    <!-- <li><a href="sub-category.php">Sub Category</a></li>
                                    <li><a href="sub-2category.php">Sub 2 Category</a></li>
                                    <li><a href="sub-3category.php">Sub 3 Category</a></li>
                                    <li><a href="category-order.php">Category Order</a></li>
                                    <li><a href="questions.php">Questions</a></li> -->
                                </ul>
                            </li>
                            <!-- <li><a href="daily-quiz.php"><em class="fas fa-question"></em> Daily Quiz</a></li>  
                            <li><a href="ebook.php"><em class="glyphicon glyphicon-book"></em> Ebook</a></li>                         -->
                            <li>
                                <a><em class="fas fa-book"></em> Government Calender<span class="fas fa-caret-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="add_government.php">Add</a></li>
                                    <!-- <li><a href="learning-category-order.php">Category Order</a></li>
                                    <li><a href="learning.php"> Manage Learning</a></li> -->
                                    <!-- <li><a href="learning-questions.php"> Questions</a></li> -->
                                </ul>
                            </li>
                            <!-- <li>
                                <a><i class="fas fa-gift"></i> Contests<span class="fas fa-caret-down"></span></a>
                                <ul class="nav child_menu">
                                    <li><a href="contest.php"><i class="fas fa-gift"></i> Manage Contest</a></li>
                                    <li><a href="contest-questions.php"><i class="fas fa-question-circle"></i> Manage Questions</a></li>
                                    <li><a href="contest-questions-import.php"><i class="fas fa-upload"></i> Import Questions</a></li>
                                </ul>
                            </li> -->
                            <li><a><em class="fas fa-book"></em> Pdf<span class="fas fa-caret-down"></span></a>
                            <ul class="nav child_menu">
                                    <li><a href="add_pdf.php">Add</a></li>
</ul>
                        </li>
                           
                                <!--<li><a href="send-notifications.php"><em class="fas fa-bullhorn"></em> Send Notifications</a></li>
                           
                            <li><a href="import-questions.php"><em class="fas fa-upload"></em> Import Questions</a></li>
                            
                                <li><a href="user-accounts-rights.php"><em class="fas fa-user"></em> User Accounts and Rights</a></li>-->
                                <!-- <li>
                                    <a><em class="fas fa-cog"></em> Settings<span class="fas fa-caret-down"></span></a>
                                    <ul class="nav child_menu">
                                        <li><a href="system-configurations.php">System Configurations</a></li>
                                        <li><a href="notification-settings.php">Notification Settings</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="instructions.php">Instructions</a></li>
                                        <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                        <li><a href="terms-conditions.php">Terms Conditions</a></li>    
                                        <li><a href="web-firebase-settings.php">Web Firebase Settings</a></li>                                       
                                    </ul>
                                </li> -->
                                <!--<li><a href="system-update.php"><em class="fas fa-cloud-download-alt"></em> System Update</a></li>-->
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- top navigation -->
        <div class="top_nav">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><em class="fa fa-bars"></em></a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="password.php"><em class="fa fa-key pull-right"></em> Change Password</a></li>
                                <li><a href="logout.php"><em class="fas fa-sign-out-alt pull-right"></em> Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- /top navigation -->